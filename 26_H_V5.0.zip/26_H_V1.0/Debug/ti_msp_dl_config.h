/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)



#define CPUCLK_FREQ                                                     80000000
/* Defines for SYSPLL_ERR_01 Workaround */
/* Represent 1.000 as 1000 */
#define FLOAT_TO_INT_SCALE                                               (1000U)
#define FCC_EXPECTED_RATIO                                                  2500
#define FCC_UPPER_BOUND                       (FCC_EXPECTED_RATIO * (1 + 0.003))
#define FCC_LOWER_BOUND                       (FCC_EXPECTED_RATIO * (1 - 0.003))

bool SYSCFG_DL_SYSCTL_SYSPLL_init(void);


/* Defines for DCC_100_PWM1 */
#define DCC_100_PWM1_INST                                                  TIMG8
#define DCC_100_PWM1_INST_IRQHandler                            TIMG8_IRQHandler
#define DCC_100_PWM1_INST_INT_IRQN                              (TIMG8_INT_IRQn)
#define DCC_100_PWM1_INST_CLK_FREQ                                      10000000
/* GPIO defines for channel 0 */
#define GPIO_DCC_100_PWM1_C0_PORT                                          GPIOA
#define GPIO_DCC_100_PWM1_C0_PIN                                   DL_GPIO_PIN_1
#define GPIO_DCC_100_PWM1_C0_IOMUX                                (IOMUX_PINCM2)
#define GPIO_DCC_100_PWM1_C0_IOMUX_FUNC               IOMUX_PINCM2_PF_TIMG8_CCP0
#define GPIO_DCC_100_PWM1_C0_IDX                             DL_TIMER_CC_0_INDEX

/* Defines for DCC_100_PWM2 */
#define DCC_100_PWM2_INST                                                  TIMA0
#define DCC_100_PWM2_INST_IRQHandler                            TIMA0_IRQHandler
#define DCC_100_PWM2_INST_INT_IRQN                              (TIMA0_INT_IRQn)
#define DCC_100_PWM2_INST_CLK_FREQ                                      10000000
/* GPIO defines for channel 0 */
#define GPIO_DCC_100_PWM2_C0_PORT                                          GPIOA
#define GPIO_DCC_100_PWM2_C0_PIN                                   DL_GPIO_PIN_0
#define GPIO_DCC_100_PWM2_C0_IOMUX                                (IOMUX_PINCM1)
#define GPIO_DCC_100_PWM2_C0_IOMUX_FUNC               IOMUX_PINCM1_PF_TIMA0_CCP0
#define GPIO_DCC_100_PWM2_C0_IDX                             DL_TIMER_CC_0_INDEX

/* Defines for DCC_100_PWM3 */
#define DCC_100_PWM3_INST                                                  TIMG6
#define DCC_100_PWM3_INST_IRQHandler                            TIMG6_IRQHandler
#define DCC_100_PWM3_INST_INT_IRQN                              (TIMG6_INT_IRQn)
#define DCC_100_PWM3_INST_CLK_FREQ                                      10000000
/* GPIO defines for channel 0 */
#define GPIO_DCC_100_PWM3_C0_PORT                                          GPIOB
#define GPIO_DCC_100_PWM3_C0_PIN                                   DL_GPIO_PIN_2
#define GPIO_DCC_100_PWM3_C0_IOMUX                               (IOMUX_PINCM15)
#define GPIO_DCC_100_PWM3_C0_IOMUX_FUNC              IOMUX_PINCM15_PF_TIMG6_CCP0
#define GPIO_DCC_100_PWM3_C0_IDX                             DL_TIMER_CC_0_INDEX



/* Defines for TIMER_xunji_pid */
#define TIMER_xunji_pid_INST                                             (TIMG7)
#define TIMER_xunji_pid_INST_IRQHandler                         TIMG7_IRQHandler
#define TIMER_xunji_pid_INST_INT_IRQN                           (TIMG7_INT_IRQn)
#define TIMER_xunji_pid_INST_LOAD_VALUE                                   (799U)




/* Defines for I2C_OLED */
#define I2C_OLED_INST                                                       I2C0
#define I2C_OLED_INST_IRQHandler                                 I2C0_IRQHandler
#define I2C_OLED_INST_INT_IRQN                                     I2C0_INT_IRQn
#define I2C_OLED_BUS_SPEED_HZ                                             400000
#define GPIO_I2C_OLED_SDA_PORT                                             GPIOA
#define GPIO_I2C_OLED_SDA_PIN                                     DL_GPIO_PIN_28
#define GPIO_I2C_OLED_IOMUX_SDA                                   (IOMUX_PINCM3)
#define GPIO_I2C_OLED_IOMUX_SDA_FUNC                    IOMUX_PINCM3_PF_I2C0_SDA
#define GPIO_I2C_OLED_SCL_PORT                                             GPIOA
#define GPIO_I2C_OLED_SCL_PIN                                     DL_GPIO_PIN_31
#define GPIO_I2C_OLED_IOMUX_SCL                                   (IOMUX_PINCM6)
#define GPIO_I2C_OLED_IOMUX_SCL_FUNC                    IOMUX_PINCM6_PF_I2C0_SCL


/* Defines for UART_0 */
#define UART_0_INST                                                        UART0
#define UART_0_INST_FREQUENCY                                           40000000
#define UART_0_INST_IRQHandler                                  UART0_IRQHandler
#define UART_0_INST_INT_IRQN                                      UART0_INT_IRQn
#define GPIO_UART_0_RX_PORT                                                GPIOA
#define GPIO_UART_0_TX_PORT                                                GPIOA
#define GPIO_UART_0_RX_PIN                                        DL_GPIO_PIN_11
#define GPIO_UART_0_TX_PIN                                        DL_GPIO_PIN_10
#define GPIO_UART_0_IOMUX_RX                                     (IOMUX_PINCM22)
#define GPIO_UART_0_IOMUX_TX                                     (IOMUX_PINCM21)
#define GPIO_UART_0_IOMUX_RX_FUNC                      IOMUX_PINCM22_PF_UART0_RX
#define GPIO_UART_0_IOMUX_TX_FUNC                      IOMUX_PINCM21_PF_UART0_TX
#define UART_0_BAUD_RATE                                                (115200)
#define UART_0_IBRD_40_MHZ_115200_BAUD                                      (21)
#define UART_0_FBRD_40_MHZ_115200_BAUD                                      (45)
/* Defines for UART1_SENSOR */
#define UART1_SENSOR_INST                                                  UART1
#define UART1_SENSOR_INST_FREQUENCY                                     40000000
#define UART1_SENSOR_INST_IRQHandler                            UART1_IRQHandler
#define UART1_SENSOR_INST_INT_IRQN                                UART1_INT_IRQn
#define GPIO_UART1_SENSOR_RX_PORT                                          GPIOA
#define GPIO_UART1_SENSOR_TX_PORT                                          GPIOA
#define GPIO_UART1_SENSOR_RX_PIN                                   DL_GPIO_PIN_9
#define GPIO_UART1_SENSOR_TX_PIN                                   DL_GPIO_PIN_8
#define GPIO_UART1_SENSOR_IOMUX_RX                               (IOMUX_PINCM20)
#define GPIO_UART1_SENSOR_IOMUX_TX                               (IOMUX_PINCM19)
#define GPIO_UART1_SENSOR_IOMUX_RX_FUNC                IOMUX_PINCM20_PF_UART1_RX
#define GPIO_UART1_SENSOR_IOMUX_TX_FUNC                IOMUX_PINCM19_PF_UART1_TX
#define UART1_SENSOR_BAUD_RATE                                          (115200)
#define UART1_SENSOR_IBRD_40_MHZ_115200_BAUD                                (21)
#define UART1_SENSOR_FBRD_40_MHZ_115200_BAUD                                (45)
/* Defines for vision */
#define vision_INST                                                        UART2
#define vision_INST_FREQUENCY                                           40000000
#define vision_INST_IRQHandler                                  UART2_IRQHandler
#define vision_INST_INT_IRQN                                      UART2_INT_IRQn
#define GPIO_vision_RX_PORT                                                GPIOA
#define GPIO_vision_TX_PORT                                                GPIOA
#define GPIO_vision_RX_PIN                                        DL_GPIO_PIN_22
#define GPIO_vision_TX_PIN                                        DL_GPIO_PIN_21
#define GPIO_vision_IOMUX_RX                                     (IOMUX_PINCM47)
#define GPIO_vision_IOMUX_TX                                     (IOMUX_PINCM46)
#define GPIO_vision_IOMUX_RX_FUNC                      IOMUX_PINCM47_PF_UART2_RX
#define GPIO_vision_IOMUX_TX_FUNC                      IOMUX_PINCM46_PF_UART2_TX
#define vision_BAUD_RATE                                                (115200)
#define vision_IBRD_40_MHZ_115200_BAUD                                      (21)
#define vision_FBRD_40_MHZ_115200_BAUD                                      (45)





/* Port definition for Pin Group KEY1 */
#define KEY1_PORT                                                        (GPIOB)

/* Defines for KEY_1: GPIOB.0 with pinCMx 12 on package pin 47 */
#define KEY1_KEY_1_PIN                                           (DL_GPIO_PIN_0)
#define KEY1_KEY_1_IOMUX                                         (IOMUX_PINCM12)
/* Port definition for Pin Group KEY2 */
#define KEY2_PORT                                                        (GPIOA)

/* Defines for KEY_2: GPIOA.2 with pinCMx 7 on package pin 42 */
#define KEY2_KEY_2_PIN                                           (DL_GPIO_PIN_2)
#define KEY2_KEY_2_IOMUX                                          (IOMUX_PINCM7)
/* Port definition for Pin Group KEY3 */
#define KEY3_PORT                                                        (GPIOB)

/* Defines for KEY_3: GPIOB.16 with pinCMx 33 on package pin 4 */
#define KEY3_KEY_3_PIN                                          (DL_GPIO_PIN_16)
#define KEY3_KEY_3_IOMUX                                         (IOMUX_PINCM33)
/* Port definition for Pin Group BUZZER */
#define BUZZER_PORT                                                      (GPIOB)

/* Defines for buzzer: GPIOB.13 with pinCMx 30 on package pin 1 */
#define BUZZER_buzzer_PIN                                       (DL_GPIO_PIN_13)
#define BUZZER_buzzer_IOMUX                                      (IOMUX_PINCM30)
/* Port definition for Pin Group LED */
#define LED_PORT                                                         (GPIOB)

/* Defines for LED3: GPIOB.25 with pinCMx 56 on package pin 27 */
#define LED_LED3_PIN                                            (DL_GPIO_PIN_25)
#define LED_LED3_IOMUX                                           (IOMUX_PINCM56)
/* Defines for LED4: GPIOB.26 with pinCMx 57 on package pin 28 */
#define LED_LED4_PIN                                            (DL_GPIO_PIN_26)
#define LED_LED4_IOMUX                                           (IOMUX_PINCM57)
/* Defines for DIR2: GPIOA.13 with pinCMx 35 on package pin 6 */
#define STEP_MOTOR_DIR2_PORT                                             (GPIOA)
#define STEP_MOTOR_DIR2_PIN                                     (DL_GPIO_PIN_13)
#define STEP_MOTOR_DIR2_IOMUX                                    (IOMUX_PINCM35)
/* Defines for DIR1: GPIOA.12 with pinCMx 34 on package pin 5 */
#define STEP_MOTOR_DIR1_PORT                                             (GPIOA)
#define STEP_MOTOR_DIR1_PIN                                     (DL_GPIO_PIN_12)
#define STEP_MOTOR_DIR1_IOMUX                                    (IOMUX_PINCM34)
/* Defines for EN1: GPIOB.22 with pinCMx 50 on package pin 21 */
#define STEP_MOTOR_EN1_PORT                                              (GPIOB)
#define STEP_MOTOR_EN1_PIN                                      (DL_GPIO_PIN_22)
#define STEP_MOTOR_EN1_IOMUX                                     (IOMUX_PINCM50)
/* Defines for EN2: GPIOB.23 with pinCMx 51 on package pin 22 */
#define STEP_MOTOR_EN2_PORT                                              (GPIOB)
#define STEP_MOTOR_EN2_PIN                                      (DL_GPIO_PIN_23)
#define STEP_MOTOR_EN2_IOMUX                                     (IOMUX_PINCM51)
/* Defines for EN3: GPIOB.3 with pinCMx 16 on package pin 51 */
#define STEP_MOTOR_EN3_PORT                                              (GPIOB)
#define STEP_MOTOR_EN3_PIN                                       (DL_GPIO_PIN_3)
#define STEP_MOTOR_EN3_IOMUX                                     (IOMUX_PINCM16)
/* Defines for DIR3: GPIOB.1 with pinCMx 13 on package pin 48 */
#define STEP_MOTOR_DIR3_PORT                                             (GPIOB)
#define STEP_MOTOR_DIR3_PIN                                      (DL_GPIO_PIN_1)
#define STEP_MOTOR_DIR3_IOMUX                                    (IOMUX_PINCM13)


/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);

bool SYSCFG_DL_SYSCTL_SYSPLL_init(void);
void SYSCFG_DL_DCC_100_PWM1_init(void);
void SYSCFG_DL_DCC_100_PWM2_init(void);
void SYSCFG_DL_DCC_100_PWM3_init(void);
void SYSCFG_DL_TIMER_xunji_pid_init(void);
void SYSCFG_DL_I2C_OLED_init(void);
void SYSCFG_DL_UART_0_init(void);
void SYSCFG_DL_UART1_SENSOR_init(void);
void SYSCFG_DL_vision_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
