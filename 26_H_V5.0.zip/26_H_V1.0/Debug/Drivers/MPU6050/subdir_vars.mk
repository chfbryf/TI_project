################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/MPU6050/mpu6050.c 

C_DEPS += \
./Drivers/MPU6050/mpu6050.d 

OBJS += \
./Drivers/MPU6050/mpu6050.o 

OBJS__QUOTED += \
"Drivers\MPU6050\mpu6050.o" 

C_DEPS__QUOTED += \
"Drivers\MPU6050\mpu6050.d" 

C_SRCS__QUOTED += \
"../Drivers/MPU6050/mpu6050.c" 


