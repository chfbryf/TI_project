################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
Drivers/MPU6050/%.o: ../Drivers/MPU6050/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"E:/TI/ti_cgt_arm_llvm_4.0.2.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -I"D:/STM32hal/ti_work/m0_template/Drivers/LSM6DSV16X" -I"D:/STM32hal/ti_work/m0_template/Drivers/VL53L0X" -I"D:/STM32hal/ti_work/m0_template/Drivers/WIT" -I"D:/STM32hal/ti_work/m0_template/Drivers/BNO08X_UART_RVC" -I"D:/STM32hal/ti_work/m0_template/Drivers/Ultrasonic_GPIO" -I"D:/STM32hal/ti_work/m0_template/Drivers/Ultrasonic_Capture" -I"D:/STM32hal/ti_work/m0_template/Drivers/OLED_Hardware_I2C" -I"D:/STM32hal/ti_work/m0_template/Drivers/OLED_Hardware_SPI" -I"D:/STM32hal/ti_work/m0_template/Drivers/OLED_Software_I2C" -I"D:/STM32hal/ti_work/m0_template/Drivers/OLED_Software_SPI" -I"D:/STM32hal/ti_work/m0_template/Drivers/MPU6050" -I"D:/STM32hal/ti_work/m0_template" -I"D:/STM32hal/ti_work/m0_template/Debug" -I"C:/TI/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include" -I"C:/TI/mspm0_sdk_2_10_00_04/source" -I"D:/STM32hal/ti_work/m0_template/Drivers/MSPM0" -DMOTION_DRIVER_TARGET_MSPM0 -DMPU6050 -D__MSPM0G3507__ -gdwarf-3 -MMD -MP -MF"Drivers/MPU6050/$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


