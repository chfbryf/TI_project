################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/MSPM0/clock.c \
../Drivers/MSPM0/interrupt.c \
../Drivers/MSPM0/ir_tracking.c \
../Drivers/MSPM0/key.c \
../Drivers/MSPM0/sensor2.c \
../Drivers/MSPM0/step_motor.c \
../Drivers/MSPM0/step_track.c \
../Drivers/MSPM0/sys.c \
../Drivers/MSPM0/task.c \
../Drivers/MSPM0/vision.c \
../Drivers/MSPM0/vision_control.c 

C_DEPS += \
./Drivers/MSPM0/clock.d \
./Drivers/MSPM0/interrupt.d \
./Drivers/MSPM0/ir_tracking.d \
./Drivers/MSPM0/key.d \
./Drivers/MSPM0/sensor2.d \
./Drivers/MSPM0/step_motor.d \
./Drivers/MSPM0/step_track.d \
./Drivers/MSPM0/sys.d \
./Drivers/MSPM0/task.d \
./Drivers/MSPM0/vision.d \
./Drivers/MSPM0/vision_control.d 

OBJS += \
./Drivers/MSPM0/clock.o \
./Drivers/MSPM0/interrupt.o \
./Drivers/MSPM0/ir_tracking.o \
./Drivers/MSPM0/key.o \
./Drivers/MSPM0/sensor2.o \
./Drivers/MSPM0/step_motor.o \
./Drivers/MSPM0/step_track.o \
./Drivers/MSPM0/sys.o \
./Drivers/MSPM0/task.o \
./Drivers/MSPM0/vision.o \
./Drivers/MSPM0/vision_control.o 

OBJS__QUOTED += \
"Drivers\MSPM0\clock.o" \
"Drivers\MSPM0\interrupt.o" \
"Drivers\MSPM0\ir_tracking.o" \
"Drivers\MSPM0\key.o" \
"Drivers\MSPM0\sensor2.o" \
"Drivers\MSPM0\step_motor.o" \
"Drivers\MSPM0\step_track.o" \
"Drivers\MSPM0\sys.o" \
"Drivers\MSPM0\task.o" \
"Drivers\MSPM0\vision.o" \
"Drivers\MSPM0\vision_control.o" 

C_DEPS__QUOTED += \
"Drivers\MSPM0\clock.d" \
"Drivers\MSPM0\interrupt.d" \
"Drivers\MSPM0\ir_tracking.d" \
"Drivers\MSPM0\key.d" \
"Drivers\MSPM0\sensor2.d" \
"Drivers\MSPM0\step_motor.d" \
"Drivers\MSPM0\step_track.d" \
"Drivers\MSPM0\sys.d" \
"Drivers\MSPM0\task.d" \
"Drivers\MSPM0\vision.d" \
"Drivers\MSPM0\vision_control.d" 

C_SRCS__QUOTED += \
"../Drivers/MSPM0/clock.c" \
"../Drivers/MSPM0/interrupt.c" \
"../Drivers/MSPM0/ir_tracking.c" \
"../Drivers/MSPM0/key.c" \
"../Drivers/MSPM0/sensor2.c" \
"../Drivers/MSPM0/step_motor.c" \
"../Drivers/MSPM0/step_track.c" \
"../Drivers/MSPM0/sys.c" \
"../Drivers/MSPM0/task.c" \
"../Drivers/MSPM0/vision.c" \
"../Drivers/MSPM0/vision_control.c" 


