################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
Drivers/OLED_Hardware_I2C/%.o: ../Drivers/OLED_Hardware_I2C/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"E:/TI/ti_cgt_arm_llvm_4.0.2.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -I"E:/git_project/TI_project/26_H_01/Drivers/LSM6DSV16X" -I"E:/git_project/TI_project/26_H_01/Drivers/VL53L0X" -I"E:/git_project/TI_project/26_H_01/Drivers/WIT" -I"E:/git_project/TI_project/26_H_01/Drivers/BNO08X_UART_RVC" -I"E:/git_project/TI_project/26_H_01/Drivers/Ultrasonic_GPIO" -I"E:/git_project/TI_project/26_H_01/Drivers/Ultrasonic_Capture" -I"E:/git_project/TI_project/26_H_01/Drivers/OLED_Hardware_I2C" -I"E:/git_project/TI_project/26_H_01/Drivers/OLED_Hardware_SPI" -I"E:/git_project/TI_project/26_H_01/Drivers/OLED_Software_I2C" -I"E:/git_project/TI_project/26_H_01/Drivers/OLED_Software_SPI" -I"E:/git_project/TI_project/26_H_01/Drivers/MPU6050" -I"E:/git_project/TI_project/26_H_01" -I"E:/git_project/TI_project/26_H_01/Debug" -I"C:/TI/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include" -I"C:/TI/mspm0_sdk_2_10_00_04/source" -I"E:/git_project/TI_project/26_H_01/Drivers/MSPM0" -DMOTION_DRIVER_TARGET_MSPM0 -DMPU6050 -D__MSPM0G3507__ -gdwarf-3 -MMD -MP -MF"Drivers/OLED_Hardware_I2C/$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


