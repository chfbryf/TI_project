################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"E:/TI/ti_cgt_arm_llvm_4.0.2.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -I"E:/git_project/TI_project/26_H_01/Drivers/LSM6DSV16X" -I"E:/git_project/TI_project/26_H_01/Drivers/VL53L0X" -I"E:/git_project/TI_project/26_H_01/Drivers/WIT" -I"E:/git_project/TI_project/26_H_01/Drivers/BNO08X_UART_RVC" -I"E:/git_project/TI_project/26_H_01/Drivers/Ultrasonic_GPIO" -I"E:/git_project/TI_project/26_H_01/Drivers/Ultrasonic_Capture" -I"E:/git_project/TI_project/26_H_01/Drivers/OLED_Hardware_I2C" -I"E:/git_project/TI_project/26_H_01/Drivers/OLED_Hardware_SPI" -I"E:/git_project/TI_project/26_H_01/Drivers/OLED_Software_I2C" -I"E:/git_project/TI_project/26_H_01/Drivers/OLED_Software_SPI" -I"E:/git_project/TI_project/26_H_01/Drivers/MPU6050" -I"E:/git_project/TI_project/26_H_01" -I"E:/git_project/TI_project/26_H_01/Debug" -I"C:/TI/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include" -I"C:/TI/mspm0_sdk_2_10_00_04/source" -I"E:/git_project/TI_project/26_H_01/Drivers/MSPM0" -DMOTION_DRIVER_TARGET_MSPM0 -DMPU6050 -D__MSPM0G3507__ -gdwarf-3 -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

build-830669019: ../test.syscfg
	@echo 'SysConfig - building file: "$<"'
	"C:/TI/sysconfig_1.26.2/sysconfig_cli.bat" -s "C:/TI/mspm0_sdk_2_10_00_04/.metadata/product.json" --script "E:/git_project/TI_project/26_H_01/test.syscfg" -o "." --compiler ticlang
	@echo 'Finished building: "$<"'
	@echo ' '

device_linker.cmd: build-830669019 ../test.syscfg
device.opt: build-830669019
device.cmd.genlibs: build-830669019
ti_msp_dl_config.c: build-830669019
ti_msp_dl_config.h: build-830669019
Event.dot: build-830669019

%.o: ./%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"E:/TI/ti_cgt_arm_llvm_4.0.2.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -I"E:/git_project/TI_project/26_H_01/Drivers/LSM6DSV16X" -I"E:/git_project/TI_project/26_H_01/Drivers/VL53L0X" -I"E:/git_project/TI_project/26_H_01/Drivers/WIT" -I"E:/git_project/TI_project/26_H_01/Drivers/BNO08X_UART_RVC" -I"E:/git_project/TI_project/26_H_01/Drivers/Ultrasonic_GPIO" -I"E:/git_project/TI_project/26_H_01/Drivers/Ultrasonic_Capture" -I"E:/git_project/TI_project/26_H_01/Drivers/OLED_Hardware_I2C" -I"E:/git_project/TI_project/26_H_01/Drivers/OLED_Hardware_SPI" -I"E:/git_project/TI_project/26_H_01/Drivers/OLED_Software_I2C" -I"E:/git_project/TI_project/26_H_01/Drivers/OLED_Software_SPI" -I"E:/git_project/TI_project/26_H_01/Drivers/MPU6050" -I"E:/git_project/TI_project/26_H_01" -I"E:/git_project/TI_project/26_H_01/Debug" -I"C:/TI/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include" -I"C:/TI/mspm0_sdk_2_10_00_04/source" -I"E:/git_project/TI_project/26_H_01/Drivers/MSPM0" -DMOTION_DRIVER_TARGET_MSPM0 -DMPU6050 -D__MSPM0G3507__ -gdwarf-3 -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

startup_mspm0g350x_ticlang.o: C:/TI/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"E:/TI/ti_cgt_arm_llvm_4.0.2.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -I"E:/git_project/TI_project/26_H_01/Drivers/LSM6DSV16X" -I"E:/git_project/TI_project/26_H_01/Drivers/VL53L0X" -I"E:/git_project/TI_project/26_H_01/Drivers/WIT" -I"E:/git_project/TI_project/26_H_01/Drivers/BNO08X_UART_RVC" -I"E:/git_project/TI_project/26_H_01/Drivers/Ultrasonic_GPIO" -I"E:/git_project/TI_project/26_H_01/Drivers/Ultrasonic_Capture" -I"E:/git_project/TI_project/26_H_01/Drivers/OLED_Hardware_I2C" -I"E:/git_project/TI_project/26_H_01/Drivers/OLED_Hardware_SPI" -I"E:/git_project/TI_project/26_H_01/Drivers/OLED_Software_I2C" -I"E:/git_project/TI_project/26_H_01/Drivers/OLED_Software_SPI" -I"E:/git_project/TI_project/26_H_01/Drivers/MPU6050" -I"E:/git_project/TI_project/26_H_01" -I"E:/git_project/TI_project/26_H_01/Debug" -I"C:/TI/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include" -I"C:/TI/mspm0_sdk_2_10_00_04/source" -I"E:/git_project/TI_project/26_H_01/Drivers/MSPM0" -DMOTION_DRIVER_TARGET_MSPM0 -DMPU6050 -D__MSPM0G3507__ -gdwarf-3 -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


